# Render CLI

## Installation

- [Homebrew](https://render.com/docs/cli#homebrew-macos-linux)
- [Direct Download](https://render.com/docs/cli#direct-download)

## Documentation

Documentation is hosted at https://render.com/docs/cli
